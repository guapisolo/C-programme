//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by BoxMan.rc
//
#define IDD_ABOUTBOX                    100
#define IDP_OLE_INIT_FAILED             100
#define IDR_MAINFRAME                   128
#define IDR_BoxManTYPE                  129
#define IDD_HELP                        130
#define IDB_BP_HELP                     131
#define IDD_LOAD_MAP                    132
#define IDC_STATIC_P                    1003
#define IDC_EDIT_LOAD_NUM               1004
#define IDC_STATIC_MAX_NUM              1005
#define ID_32771                        32771
#define ID_32772                        32772
#define ID_32773                        32773
#define ID_MENU_GAME_LEVEL              32774
#define ID_MENU_GAME_MUSIC              32775
#define ID_MENU_GAME_HELP               32776
#define ID_32777                        32777

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        133
#define _APS_NEXT_COMMAND_VALUE         32778
#define _APS_NEXT_CONTROL_VALUE         1006
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
